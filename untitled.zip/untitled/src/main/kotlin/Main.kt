import java.util.concurrent.CountDownLatch
import java.util.concurrent.locks.Condition
import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock

val lol = ReentrantLock()
val rofl = ReentrantLock()
val latch = CountDownLatch(100)
val cond1: Condition = rofl.newCondition()
val cond2: Condition = rofl.newCondition()

var stop = false
var l = 0
var data = ""
var running = false
var thread: Thread? = null

fun main() {
    var i = 0

    while(i < 100) {

        Thread {
            lol.lock()
            Thread.sleep(25)

            rofl.withLock {
                if (!running) {
                    thread = Thread(LOL())
                    thread!!.start()
                    cond1.await()
                }

                data = "bla ${l+1}"
                l++

                println(data)
                cond2.signal()
                cond1.await()
                latch.countDown()
            }

            lol.unlock()

        }.start()
        i++
    }

    latch.await()
    stop = true

    rofl.withLock {
        cond2.signal()
    }

    println("DONE BISH!!!! IM DONE!!! I GIVE UP!!!!!")
}

class LOL: Runnable {
    override fun run() {
        rofl.withLock {
            cond1.signal()
            while(!stop) {
                if (!running)
                    start()
                cond2.await()
                cond1.signal()
            }
            cond1.signal()
        }
    }

    private fun start () {
        running = true
    }
}